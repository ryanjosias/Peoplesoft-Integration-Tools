package PeopleCodeGenerator;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;

public class Main {
public static ArrayList<String> nodesList = new ArrayList<>();


    public static void main(String[] args) {
        try
        {
            System.out.println("******************************************");
            System.out.println("*  XML Document to PeopleCode Converter  *");
            System.out.println("******************************************");
            System.out.println("Enter the file location of the XML Document:");
            Scanner scanner = new Scanner(System.in);
            String filelocation = scanner.nextLine();
            System.out.println("Enter the name of the PeopleSoft Service Operation invoking the webservice:");
            scanner = new Scanner(System.in);
            String operationName = scanner.nextLine();

            File file = new File(filelocation);
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = documentBuilder.parse(file);
        //System.out.println("Root element: "+ document.getDocumentElement().getNodeName());


            if (document.hasChildNodes())
            { initiateCode(operationName);
               printNodeList(document.getChildNodes(), "");
               endCode();

            }

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }


        private static void initiateCode(String operationName) {

            System.out.println("C");

            System.out.println("rem Create your MESSAGE here - ******.");
            System.out.println("rem Local Message &RequestMSG = CreateMessage(Operation."+ operationName +", %IntBroker_Request);");
            System.out.println("Local XmlDoc &RequestDOC = CreateXmlDoc(\"\");");
            System.out.println("Local SOAPDoc &soap = CreateSOAPDoc();");
            System.out.println("&soap.AddEnvelope(%SOAP_Custom);");
            System.out.println("&soap.AddBody();");
            System.out.println("Local XmlNode &EnvelopeNode = &doc.EnvelopeNode;");
            System.out.println("Local XmlNode &BodyNode = &doc.BodyNode;");
            System.out.println();

    }

    private static void endCode() {
        System.out.println();
        System.out.println("RequestDOC = &soap.XmlDoc;");
        System.out.println("&RequestMSG.SetXmlDoc(&RequestDOC);");
    }


//UUID idOne = UUID


    private static void printNodeList(NodeList nodeList, String collection)
    {
     //   System.out.println("Node List =" + nodeList.item(1));
        int counter = 0;

        for (int count = 1; count < nodeList.getLength()+1; count++)
        {

            Node elemNode = nodeList.item(count-1);
            //NodeMap Mapping = new NodeMap(elemNode.getParentNode(), 1, elemNode.getNodeName());



            if (elemNode.getNodeType() == Node.ELEMENT_NODE)
            {
              //  System.out.println(elemNode.getNodeName());
                collection = collection + ""+count;
// get node name and value
                String prefix = "";
                if(elemNode.getNodeName().contains(":")) {
                    int indexOfColon = elemNode.getNodeName().indexOf(":");
                    prefix = elemNode.getNodeName().substring(0, indexOfColon);
                }
                if(!prefix.toLowerCase().equals("soapenv")) {

                    System.out.println(format2(elemNode));
/*
                    if (elemNode.getChildNodes().getLength() != 1) {
                        System.out.println(formatParentNodes(elemNode,collection));
                    } else {
                        System.out.println(format(elemNode,collection));

                    }*/

                }
                if (elemNode.hasAttributes())
                {

                    NamedNodeMap nodeMap = elemNode.getAttributes();
                    for (int i = 0; i < nodeMap.getLength(); i++) {
                        Node node = nodeMap.item(i);

                        if (node.getNodeName().equals("xmlns:soapenv")) {
                        } else{
                            System.out.println("&EnvelopeNode.AddAttribute(\""+node.getNodeName()+"\", \""+node.getNodeValue()+"\")");
                    }
                    }
                    System.out.println();
                }
                if (elemNode.hasChildNodes())
                {

//recursive call if the node has child nodes
                    printNodeList(elemNode.getChildNodes(),collection);
                }
            //    System.out.println("Node Name =" + elemNode.getNodeName()+ " [CLOSE]");
            }

        }
    }

    private static String format(Node node, String collection)
    {

        String output = "Local XmlNode ";
       if( node.getNodeName().contains(":")) {
           int nodePrefixPoint = node.getNodeName().indexOf(":") + 1;
           String nodeName = "&" + node.getNodeName().substring(nodePrefixPoint)  ;
           int nodePrefixPointParent = node.getParentNode().getNodeName().indexOf(":") + 1;
           String nodeNameParent = "&" + node.getParentNode().getNodeName().substring(nodePrefixPointParent) ;
           output = output + nodeName + " = " + nodeNameParent + ".AddElement(\"" + node.getNodeName() + "\").AddText(\"\");";
       }
       else{
           String nodeName = "&" + node.getNodeName() ;
           String nodeNameParent = "&" + node.getParentNode().getNodeName();
           output = output + nodeName + " = " + nodeNameParent + ".AddElement(\"" + node.getNodeName() + "\").AddText(\"\");";
       }
        return output;

    }

    private static String formatParentNodes(Node node, String collection)
    {
        String output = "Local XmlNode ";
        if( node.getNodeName().contains(":")) {
            int nodePrefixPoint = node.getNodeName().indexOf(":") + 1;
            String nodeName = "&" + node.getNodeName().substring(nodePrefixPoint) ;
            int nodePrefixPointParent = node.getParentNode().getNodeName().indexOf(":") + 1;
            String nodeNameParent = "&" + node.getParentNode().getNodeName().substring(nodePrefixPointParent) ;
            output = output + nodeName + " = " + nodeNameParent + ".AddElement(\"" + node.getNodeName() + "\");";
        }
        else{
            String nodeName = "&" + node.getNodeName() ;
            String nodeNameParent = "&" + node.getParentNode().getNodeName() ;
            output = output + nodeName + " = " + nodeNameParent + ".AddElement(\"" + node.getNodeName() + "\");";
        }
        return output;
    }
    private static String format2(Node elemNode) {
        String output = "Local XmlNode ";
        if (elemNode.getChildNodes().getLength() != 1) {
            String nodeName = validateString(elemNode);
            String parentNodeName = validateString(elemNode.getParentNode());
            output = output + nodeName + " = " + parentNodeName + ".AddElement(\"" + elemNode.getNodeName() + "\");";
        } else {
            String nodeName = validateString(elemNode);
            String parentNodeName = validateString(elemNode.getParentNode());
            output = output + nodeName + " = " + parentNodeName + ".AddElement(\"" + elemNode.getNodeName() + "\").AddText(\"\");";
        }
            return output;
    }

    private static String validateString(Node node) {
        String nodeName = "";
        if( node.getNodeName().contains(":")) {
            int nodePrefixPoint = node.getNodeName().indexOf(":") + 1;
            nodeName = "&" + node.getNodeName().substring(nodePrefixPoint) ;

        } else {
            nodeName = "&" + node.getNodeName() ;
        }
return nodeName;
    }

}



